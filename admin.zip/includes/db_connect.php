<?php
$con=mysqli_connect('localhost','root','')OR die("could not connect to server");
mysqli_select_db($con,'addgro')OR die("could not conect to database");
//session_name('auth');
//session_start();

//require_once('includes/validate.php');

?>